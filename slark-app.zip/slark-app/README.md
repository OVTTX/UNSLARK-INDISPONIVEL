# Slark · App (fundação)

Aplicativo do ecossistema Slark — React + Vite + Tailwind + Supabase.
Conecta-se à landing page institucional por link ("Entrar no app" / "Voltar ao site").

## O que já está pronto (esta fase)
- **Login real** (Supabase) com redirecionamento por perfil.
- **4 perfis**: Equipe Slark (admin), Diretor, Professor, Aluno.
- **Sidebar dinâmica** que muda conforme o perfil logado.
- **Rotas protegidas** — cada perfil só acessa o que é dele.
- **Painel da Equipe Slark** com KPIs reais lidos do banco.
- **Schema completo do banco** (`db/schema.sql`) — todas as tabelas do ecossistema.
- Demais telas entram como placeholder, prontas para serem preenchidas fase a fase.

## Como rodar

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Crie um projeto grátis no [Supabase](https://supabase.com).

3. No painel do Supabase, abra **SQL Editor** e rode, nesta ordem:
   - `db/schema.sql` (cria as tabelas e os dados-semente)

4. Copie `.env.example` para `.env` e preencha:
   ```
   VITE_SUPABASE_URL=...        (Project Settings > API > Project URL)
   VITE_SUPABASE_ANON_KEY=...   (Project Settings > API > anon public)
   VITE_LANDING_URL=...         (URL da landing institucional)
   ```

5. Crie um usuário de teste (ver `db/usuarios_exemplo.sql`).

6. Suba o app:
   ```bash
   npm run dev
   ```
   Acesse http://localhost:5173 → será levado ao login.

## Próximas fases
1. **Painel da Equipe Slark** completo (escolas, assinaturas, pagamentos). ← próximo
2. Painel do Professor.
3. Painel do Diretor.
4. Painel do Aluno (mapa de competências, entregas, chat).

## Conexão com a landing
O botão **"Entrar no app"** na landing aponta para a URL deste app (`/login`).
Dentro do app, **"Voltar ao site"** e o logo apontam para `VITE_LANDING_URL`.
